#' weekly stock price data
#'
#' 
#'
#' @docType data
#'
#' @usage data(weekly)
#'
#' @format An dataframe of weekly stock price data
#'
#' @keywords datasets
#'
#' @examples
#' data(weekly)
#' head(weekly)
"weekly"